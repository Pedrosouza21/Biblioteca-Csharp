﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Biblioteca_BD_DS
{
    public partial class FormEmpréstimo : Form
    {
        private MySqlConnection Conexao;
        private string data_source = "server=localhost; database=bd_biblioteca; user id=root; port=3306;";
        //private string data_source = "server=localhost; database=bd_biblioteca; user id=root; password = root ; port=3306;";
        private int? id_livro;
        private int? id_usuario;
        public FormEmpréstimo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cbLivro.Text) || string.IsNullOrWhiteSpace(cbUsuario.Text))
            {

                MessageBox.Show(" Preencha todas as informações!");
            }
            else
            {
                Conexao = new MySqlConnection(data_source);
                string busca = cbLivro.Text;
                string sql2 = "Select id_livro from tb_livros WHERE ds_Nome = '" + busca + "'";
                Conexao.Open();
                MySqlCommand comando2 = new MySqlCommand(sql2, Conexao);
                MySqlDataReader reader = comando2.ExecuteReader();
                while (reader.Read())
                {
                    id_livro = reader.GetInt32(0);

                }

                Conexao = new MySqlConnection(data_source);
                string busca2 = cbUsuario.Text;
                string sql3 = "Select id_Usuario from tb_usuarios WHERE ds_Nome = '" + busca2 + "'";
                Conexao.Open();
                MySqlCommand comando3 = new MySqlCommand(sql3, Conexao);
                MySqlDataReader reader2 = comando3.ExecuteReader();
                while (reader2.Read())
                {
                    id_usuario = reader2.GetInt32(0);

                }

                try
                {
                    Conexao = new MySqlConnection(data_source);
                    string sql = "insert into tb_empr_de_livro (id_Registro, id_Livro, id_Usuario, dt_Emprest) values(default, '"+id_livro+"', '"+id_usuario+"', '"+dtEmprestimo.Value+"' )";
                    MySqlCommand comando = new MySqlCommand(sql, Conexao);
                    Conexao.Open();
                    comando.ExecuteReader();
                    MessageBox.Show("Livro emprestado!");
                    Conexao.Close();                   
                    cbUsuario.Text = "";
                    cbLivro.Text = "";
                    
                }
                catch
                {
                    MessageBox.Show("Erro no cadastro");
                }
            }
        }

        private void FormEmpréstimo_Load(object sender, EventArgs e)
        {
            Conexao = new MySqlConnection(data_source);
            Conexao.Open();
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = Conexao;
            comando.CommandText = "Select ds_Nome from tb_livros order by ds_Nome";
            MySqlDataReader dr = comando.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            cbLivro.DisplayMember = "ds_Nome";
            cbLivro.DataSource = dt;

            Conexao = new MySqlConnection(data_source);
            Conexao.Open();
            MySqlCommand comando2 = new MySqlCommand();
            comando2.Connection = Conexao;
            comando2.CommandText = "Select ds_Nome from tb_usuarios order by ds_Nome";
            MySqlDataReader dr2 = comando2.ExecuteReader();
            DataTable dt2 = new DataTable();
            dt2.Load(dr2);
            cbUsuario.DisplayMember = "ds_Nome";
            cbUsuario.DataSource = dt2;

        }


    }
}
